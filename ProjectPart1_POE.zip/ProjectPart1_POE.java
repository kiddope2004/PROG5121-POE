/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.project.part1_poe;

/**
 *
 * @author THABISO TJALE
 */

import java.util.Scanner;

    public class ProjectPart1_POE {
    
    
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Login login = new Login();
        boolean isLoggedIn = false;
        
        while (true) {
            //display menu 
            System.out.println("\n=== Menu ===");
            System.out.println("1. Register");
            System.out.println("2. Login");
            System.out.println("3. Exit");
            System.out.print("Enter choice: ");
            
            int choice = scanner.nextInt();
            scanner.nextLine();
            
            switch (choice) {
                case 1: // Register
                    System.out.print("Enter Name: ");
                    String name = scanner.nextLine();
                    
                    System.out.print("Enter Surname: ");
                    String surname = scanner.nextLine();
                    
                    System.out.print("Enter Username: ");
                    String username = scanner.nextLine();
                    
                    System.out.print("Enter your password: ");
                    String password = scanner.nextLine();
                    
                    System.out.print("Enter cell (+27...): ");
                    String cell = scanner.nextLine();
                    
                    String registrationMessage = login.registerUser(username, password, cell);
                    System.out.println(registrationMessage);
                    break;
                    
                case 2: // Login
                    System.out.print("Enter username: ");
                    String loginUser = scanner.nextLine();
                    
                    System.out.print("Enter Password: ");
                    String loginPass = scanner.nextLine();
                    
                    String loginStatus = login.returnLoginStatus(loginUser, loginPass);
                    System.out.println(loginStatus);
                    break;
                    
                case 3: // Exit
                    System.out.println("Goodbye!");
                    scanner.close();
                    return;
                    
                default:
                    System.out.println("Invalid option, try again.");
            }
        }
    }
}

